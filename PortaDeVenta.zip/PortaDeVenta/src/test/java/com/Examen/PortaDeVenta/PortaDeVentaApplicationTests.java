package com.Examen.PortaDeVenta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PortaDeVentaApplicationTests {

	@Test
	void contextLoads() {
	}

}
